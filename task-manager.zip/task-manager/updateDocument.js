const { MongoClient, ObjectId } = require('mongodb');
const url = 'mongodb://127.0.0.1:27017';
const client = new MongoClient(url);
const namaDatabase = 'task-manager';

async function main() {
  try {
    await client.connect();
    console.log('Berhasil terhubung ke MongoDB database server');

    const db = client.db(namaDatabase);

    // // Memperbaharui data dengan perintah updateOne
    // const updateOnePromise = db.collection('pengguna').updateOne(
    //   { _id: new ObjectId('656c20dcf66d23bf587c2810') },
    //   // { $set: { nama: 'natfeb' } }
    //   // atau bisa menggunakan operator $inc untuk increment usia
    //   { $inc: { usia: 1 } }
    // );

    // updateOnePromise
    //   .then((result) => {
    //     console.log(result);
    //   })
    //   .catch((error) => {
    //     console.error(error);
    //   })
    //   .finally(() => {
    //     client.close();
    //   });

    // Memperbaharui data dengan perintah updateMany
    const updateManyPromise = db.collection('tugas').updateMany(
      { StatusPenyelesaian: false },
      { $set: { StatusPenyelesaian: true } }
    );

    updateManyPromise
      .then((result) => {
        console.log(result.modifiedCount);
      })
      .catch((error) => {
        console.error(error);
      })
      .finally(() => {
        client.close();
      });
  } catch (error) {
    console.error(error);
  }
}

main();
