const { MongoClient } = require('mongodb');

const url = 'mongodb://127.0.0.1:27017';
const namaDatabase = 'task-manager';

async function main() {
    const client = new MongoClient(url);

    try {
        await client.connect();
        console.log('Berhasil terhubung ke MongoDB database server');

        const db = client.db(namaDatabase);
        const collection = db.collection('pengguna');

        const result = await collection.deleteMany({ nama : "Randi" });
        console.log(result);
    } catch (error) {
        console.error(error);
    } finally {
        await client.close();
    }
}

main();
