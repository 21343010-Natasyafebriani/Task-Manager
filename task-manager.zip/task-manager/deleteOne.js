const { MongoClient, ObjectId } = require('mongodb');

const url = 'mongodb://127.0.0.1:27017';
const namaDatabase = 'task-manager';

async function main() {
    const client = new MongoClient(url);

    try {
        await client.connect();
        console.log('Berhasil terhubung ke MongoDB database server');

        const db = client.db(namaDatabase);
        const tugasCollection = db.collection('tugas');

        const tugasIdToDelete = '656c1f21e714b5ee26c25228'; // Ganti dengan ID tugas yang ingin dihapus

        const deleteOneResult = await tugasCollection.deleteOne({ _id: new ObjectId(tugasIdToDelete) });

        if (deleteOneResult.deletedCount === 1) {
            console.log('Tugas berhasil dihapus');
        } else {
            console.log('Tidak ada tugas yang dihapus');
        }
    } catch (error) {
        console.error(error);
    } finally {
        await client.close();
    }
}

main();
